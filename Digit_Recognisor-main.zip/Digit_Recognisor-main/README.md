# Digit_Recognisor
A project that read hand written and predict the digit. 

Libraries Used: TensorFlow, Scikit-Learn, Keras, Pandas.

In this project, I created a Convolutional Neural Network(CNN) model using TensorFlow to recognize handwritten digit.
The Convolutional Neural Network is a Deep Learning algorithm which can take in an input images, assign learnable weights and biasesto various aspects in the image and able to differentiate one from another.
